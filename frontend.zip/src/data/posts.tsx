// 📂 src/data/posts.ts
export const dummyPosts = [
    { id: 1, title: "주황 빛 ", id: "우수희", image: "/images/A/A1.jpg" },
    { id: 2, title: "웃음", id: "곰수희", image: "/images/A/A3.jpg" },
    { id: 3, title: "딸기맛", id: "후라", image: "/images/A/A25.jpg" },
    { id: 4, title: "여름이였다", id: "하늘", image: "/images/A/A9.jpg" },
    { id: 6, title: "프린스", id: "창달", image: "/images/B/B2.jpg" },
    { id: 7, title: "Happy", id: "인연", image: "/images/B/B20.jpg" },
    { id: 8, title: "lon", id: "담배맛", image: "/images/B/B14.jpg" },
    { id: 9, title: "헤에에",id: "UOUO", image: "/images/B/B5.jpg" },

  ];
  